#!/usr/bin/env bash

export HADOOP_HOME=${HADOOP_HOME:-/usr/hdp/current/hadoop-client}
export HADOOP_CONF_DIR=${HADOOP_CONF_DIR:-/usr/hdp/current/hadoop-client/conf}

# The java implementation to use.
export JAVA_HOME=/usr/jdk64/jdk1.8.0_112

export SPARK_HOME=${SPARK_HOME:-/usr/hdp/current/spark-client}
export SPARK_CONF_DIR=${SPARK_CONF_DIR:-//usr/hdp/current/spark-client/conf} 