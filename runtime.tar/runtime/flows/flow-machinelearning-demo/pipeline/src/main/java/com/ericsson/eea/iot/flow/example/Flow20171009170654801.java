/*
 
*/
package com.ericsson.eea.iot.flow.example;

import java.io.Serializable;

import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.coders.CoderRegistry;
import org.apache.beam.sdk.coders.DefaultCoder;
import org.apache.beam.sdk.coders.AvroCoder;
import org.apache.beam.sdk.coders.Coder;
import org.apache.beam.sdk.coders.CoderException;
import org.apache.beam.sdk.metrics.Metrics;
import org.apache.beam.sdk.options.Default;
import org.apache.beam.sdk.options.Description;
import org.apache.beam.sdk.options.PipelineOptions;
import org.apache.beam.sdk.options.PipelineOptionsFactory;
import org.apache.beam.sdk.options.Validation.Required;
import org.apache.beam.sdk.transforms.SimpleFunction;
import org.apache.beam.sdk.values.KV;
import org.apache.beam.sdk.values.PCollection;

import com.ericsson.eea.iot.flow.node.NodeBuilder;
import com.ericsson.eea.iot.flow.node.NodeOptions;
import com.ericsson.eea.iot.flow.node.ProcessType;

/* generated node classes */
import com.ericsson.eea.iot.flow.node.sources.KafkaValueSource;
import com.ericsson.eea.iot.flow.ml.ConvertToNDArray;
import com.ericsson.eea.iot.flow.ml.NNPredictNode;
import com.ericsson.eea.iot.flow.ml.ConvertToString;
import com.ericsson.eea.iot.flow.node.sinks.KafkaSink;
/* generated node classed end */


public class Flow20171009170654801 {

	/**
	 * Options supported by {@link Flow20171009170654801}.
	 *
	 * <p>
	 *  The options are set from the generated code instead of commandline, so no member need.
	 * <p>
	 * Inherits standard configuration options.
	 */
	public interface Flow20171009170654801Options extends PipelineOptions {
	}


    
  
    private static PCollection<com.ericsson.eea.iot.flow.ml.MnistImage> pipelineNode37(Pipeline p, KafkaValueSource<com.ericsson.eea.iot.flow.ml.MnistImage> node) {
			
			return p.apply("Kafka Source", node.reader(com.ericsson.eea.iot.flow.ml.MnistImage.class));
		}
	
	    private static PCollection<org.nd4j.linalg.api.ndarray.INDArray> pipelineNode38(Pipeline p, PCollection<com.ericsson.eea.iot.flow.ml.MnistImage> pcol, ConvertToNDArray<com.ericsson.eea.iot.flow.ml.MnistImage> node) {
		PCollection<org.nd4j.linalg.api.ndarray.INDArray> col = null;
		if (node.getProcessType() == ProcessType.MAP) {
			col = pcol.apply("Converter to NDArray", node.map());
		} else if (node.getProcessType() == ProcessType.TRANSFORM) {
			col = pcol.apply("Converter to NDArray", node.transform());
		}
		return col;
	}
	    private static PCollection<java.util.List<String>> pipelineNode40(Pipeline p, PCollection<org.nd4j.linalg.api.ndarray.INDArray> pcol, NNPredictNode node) {
		PCollection<java.util.List<String>> col = null;
		if (node.getProcessType() == ProcessType.MAP) {
			col = pcol.apply("Model Predict", node.map());
		} else if (node.getProcessType() == ProcessType.TRANSFORM) {
			col = pcol.apply("Model Predict", node.transform());
		}
		return col;
	}
	    private static PCollection<String> pipelineNode42(Pipeline p, PCollection<java.util.List<String>> pcol, ConvertToString node) {
		PCollection<String> col = null;
		if (node.getProcessType() == ProcessType.MAP) {
			col = pcol.apply("Convert To String", node.map());
		} else if (node.getProcessType() == ProcessType.TRANSFORM) {
			col = pcol.apply("Convert To String", node.transform());
		}
		return col;
	}
	    private static void pipelineNode44(Pipeline p, PCollection<String> pcol, KafkaSink<String> node) {
			pcol.apply("Kafka Sink", node.writer());
		}
	    
	public static void main(String[] args) {
    /* generate option for pipeline */
		Flow20171009170654801Options options = PipelineOptionsFactory.fromArgs(args).withValidation().as(Flow20171009170654801Options.class);

		
		Pipeline p = Pipeline.create(options);

    /* generate code to build nodes */

		// generated source code for node Kafka Source 
		KafkaValueSource.Builder<com.ericsson.eea.iot.flow.ml.MnistImage> builder37 = new KafkaValueSource.Builder<com.ericsson.eea.iot.flow.ml.MnistImage>();

		builder37.setOption("bootstrap.server", "localhost:9092");
		builder37.setOption("kafka.topic", "mnist-images");
		builder37.setOption("value.deserializer", "com.ericsson.eea.iot.flow.ml.ImageDeserializer");
		builder37.setOption("auto.offset.reset", "earliest");
		builder37.setName("Kafka Source");
 
		KafkaValueSource<com.ericsson.eea.iot.flow.ml.MnistImage> node37 = builder37.build();


		// generated source code for node Converter to NDArray 
		ConvertToNDArray.Builder<com.ericsson.eea.iot.flow.ml.MnistImage> builder38 = new ConvertToNDArray.Builder<com.ericsson.eea.iot.flow.ml.MnistImage>();

		builder38.setName("Converter to NDArray");
 
		ConvertToNDArray<com.ericsson.eea.iot.flow.ml.MnistImage> node38 = builder38.build();


		// generated source code for node Model Predict 
		NodeBuilder builder40 = new NodeBuilder();

		builder40.setOption("model.location", ".\\mymodellocation.zip");
		builder40.setName("Model Predict");
		NNPredictNode node40 = builder40.build(NNPredictNode.class);


		// generated source code for node Convert To String 
		NodeBuilder builder42 = new NodeBuilder();

		builder42.setName("Convert To String");
		ConvertToString node42 = builder42.build(ConvertToString.class);


		// generated source code for node Kafka Sink 
		KafkaSink.Builder<String> builder44 = new KafkaSink.Builder<String>();

		builder44.setOption("bootstrap.server", "localhost:9092");
		builder44.setOption("kafka.topic", "mnist-results");
		builder44.setOption("value.deserializer", "org.apache.kafka.common.serialization.StringSerializer");
		builder44.setName("Kafka Sink");
 
		KafkaSink<String> node44 = builder44.build();


    /* generated the pipeline code here */
		PCollection<com.ericsson.eea.iot.flow.ml.MnistImage> pCol37 = pipelineNode37(p, node37);
		PCollection<org.nd4j.linalg.api.ndarray.INDArray> pCol38 = pipelineNode38(p, pCol37, node38);
		PCollection<java.util.List<String>> pCol40 = pipelineNode40(p, pCol38, node40);
		PCollection<String> pCol42 = pipelineNode42(p, pCol40, node42);
		pipelineNode44(p, pCol42, node44);

		p.run().waitUntilFinish();
	}
}
