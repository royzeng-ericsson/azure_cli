/*
 
*/
package {{flowDefinition.getPackage()}};

import java.io.Serializable;

import org.slf4j.LoggerFactory;
import org.slf4j.Logger;

import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.coders.CoderRegistry;
import org.apache.beam.sdk.coders.DefaultCoder;
import org.apache.beam.sdk.coders.AvroCoder;
import org.apache.beam.sdk.coders.Coder;
import org.apache.beam.sdk.coders.CoderException;
import org.apache.beam.sdk.metrics.Metrics;
import org.apache.beam.sdk.options.Default;
import org.apache.beam.sdk.options.Description;
import org.apache.beam.sdk.options.PipelineOptions;
import org.apache.beam.sdk.options.PipelineOptionsFactory;
import org.apache.beam.sdk.options.Validation.Required;
import org.apache.beam.sdk.transforms.SimpleFunction;
import org.apache.beam.sdk.values.KV;
import org.apache.beam.sdk.values.PCollection;

import com.ericsson.eea.iot.flow.node.NodeBuilder;
import com.ericsson.eea.iot.flow.node.NodeOptions;
import com.ericsson.eea.iot.flow.node.ProcessType;
import com.ericsson.eea.iot.flow.core.FValueTag;

/* generated node classes */
{% for node in nodeDefinitions%}
import {{ node.getClassPackage()}}.{{node.getClassName()}};
{% endfor %}
/* generated node classed end */

public class {{flowClassName}} {
	private static final Logger logger = LoggerFactory.getLogger({{flowClassName}}.class);

	/**
	 * Options supported by {@link {{flowClassName}}}.
	 *
	 * <p>
	 *  The options are set from the generated code instead of commandline, so no member need.
	 * <p>
	 * Inherits standard configuration options.
	 */
	public interface {{flowClassName}}Options extends PipelineOptions {
		@Description("Name of the flow")
    @Default.String("Example")
    String getName();
    void setName(String value);
	}

  {% for nodeBuildFunc in nodeBuildFuncCodes %}
  {{ nodeBuildFunc | raw }}
  {% endfor %}
  
	public static void main(String[] args) {
    /* generate option for pipeline */
		{{flowClassName}}Options options = PipelineOptionsFactory.fromArgs(args).withValidation().as({{flowClassName}}Options.class);

		
		Pipeline p = Pipeline.create(options);

    /* generate code to build nodes */
{% for nodeBuild in nodeBuildCodes %}
{{ nodeBuild | raw }}
{% endfor %}

    /* generated the pipeline code here */
{% for nodePipeline in pipelineBuildCodes %}
{{ nodePipeline | raw }}
{% endfor %}

		p.run().waitUntilFinish();
	}
}
